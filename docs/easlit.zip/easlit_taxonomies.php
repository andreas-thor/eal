<?php

class Taxonomy {
	
// 	// WORKSHOP
// 	public static $domains = array (
// 			"ws1" 	=> "Workshop #1",
// 			"ws2" 	=> "Workshop #2",
// 			"ws3" 	=> "Workshop #3",
// 			"ws4" 	=> "Workshop #4",
// 			"ws5" 	=> "Workshop #5",
// 			"ws6" 	=> "Workshop #6",
// 			"ws7" 	=> "Workshop #7",
// 			"ws8" 	=> "Workshop #8",
// 			"ws9" 	=> "Workshop #9"
// 	);
	
	public static $domains = array (
			"paedagogik" 	=> "Allgemeine Paedagogik",
			"topic" 		=> "Beispieltaxonomy",
			"datenbanken"	=> "Datenbanksysteme"
	);
	
// 	public static $domains = array (
// 			"potpourri" 	=> "Potpourri",
// 			"info" 	=> "Informatik"
// 	);
	

	// TASKTRAIN
// 	public static $domains = array (
// 			"potpourri" 	=> "Potpourri",
// 			"praxis" 	=> "Praxisaufgabe"
// 	);	
}

?>